﻿# SimpleByte Setup v2.1.2 - PowerShell 5.1+
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Catalog=Get-Content (Join-Path $Root "catalog.json") -Raw -Encoding UTF8|ConvertFrom-Json
$LogDir=Join-Path $Root "logs";if(!(Test-Path $LogDir)){New-Item $LogDir -ItemType Directory|Out-Null}
$Log=Join-Path $LogDir ("SimpleByteSetup_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".log")
function Log($s){Add-Content $Log ("[{0}] {1}"-f(Get-Date -Format "yyyy-MM-dd HH:mm:ss"),$s)}
function Has-Winget{return [bool](Get-Command winget.exe -ErrorAction SilentlyContinue)}
function Is-Admin {$id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id);return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Get-Arch {
  $a=$env:PROCESSOR_ARCHITECTURE
  if($env:PROCESSOR_ARCHITEW6432){$a=$env:PROCESSOR_ARCHITEW6432}
  switch -Regex ($a) {"ARM64"{"arm64";break}"AMD64"{"x64";break}"x86"{"x86";break}default{$a.ToLower()}}
}
function Get-FreeGB {try{$d=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'";return [math]::Round($d.FreeSpace/1GB,1)}catch{return 0}}
function Get-RamGB {try{$c=Get-CimInstance Win32_ComputerSystem;return [math]::Round($c.TotalPhysicalMemory/1GB,1)}catch{return 0}}
function Get-Build {try{return [int](Get-CimInstance Win32_OperatingSystem).BuildNumber}catch{return 0}}
function Get-Virt {
 try{
  $c=Get-CimInstance Win32_Processor|Select-Object -First 1
  if($null-ne$c.VirtualizationFirmwareEnabled){return [bool]$c.VirtualizationFirmwareEnabled}
 }catch{}
 return $null
}
function IsInstalled($id){if($id -like "github:*" -or $id -like "reference:*" -or $id -eq "microsoft:office365-odt"){return $false};if(!(Has-Winget)){return $false};$x=& winget list --id $id -e --accept-source-agreements 2>&1|Out-String;return $x-match[regex]::Escape($id)}
function PackageAvailable($id){
 if($id -like "github:*" -or $id -like "reference:*" -or $id -eq "microsoft:office365-odt"){return @{Ok=$true;Text="Fuente oficial/especial"}}
 if(!(Has-Winget)){return @{Ok=$false;Text="WinGet no disponible"}}
 $x=& winget show --id $id -e --accept-source-agreements 2>&1|Out-String
 $ok=($LASTEXITCODE-eq 0 -and $x -notmatch "No package found|No se encontr")
 return @{Ok=$ok;Text=$x}
}
function Test-Compatibility($a,[bool]$CheckPackage=$true){
 $hard=@();$warn=@();$ok=@()
 $arch=Get-Arch;$ram=Get-RamGB;$free=Get-FreeGB;$build=Get-Build;$virt=Get-Virt
 $ok+="Windows build $build";$ok+="Arquitectura: $arch";$ok+="RAM: $ram GB";$ok+="Libre en $env:SystemDrive`: $free GB"
 if($a.requirements){
   $arches=@($a.requirements.architectures)
   if($arches.Count -and $arches -notcontains $arch){$hard+="Arquitectura $arch no incluida en requisitos documentados ($($arches -join ', '))."}
   if([double]$a.requirements.minRamGB -gt 0 -and $ram -lt [double]$a.requirements.minRamGB){$hard+="RAM insuficiente: $ram GB; mínimo documentado $($a.requirements.minRamGB) GB."}
   elseif([double]$a.requirements.recommendedRamGB -gt 0 -and $ram -lt [double]$a.requirements.recommendedRamGB){$warn+="RAM $ram GB; recomendado documentado $($a.requirements.recommendedRamGB) GB."}
   if([double]$a.requirements.minDiskGB -gt 0 -and $free -lt [double]$a.requirements.minDiskGB){$hard+="Espacio insuficiente: $free GB; mínimo documentado $($a.requirements.minDiskGB) GB."}
   if($a.requirements.requiresVirtualization){
      if($virt -eq $false){$hard+="Virtualización de hardware no está habilitada."}
      elseif($null -eq $virt){$warn+="No se pudo determinar si la virtualización está habilitada."}
      else{$ok+="Virtualización: habilitada"}
   }
   foreach($n in @($a.requirements.notes)){if($n){$warn+=$n}}
 }
 if($a.installMode -eq "external" -or $a.installMode -eq "reference"){
   $warn+="Fuente externa: SimpleByte no realizará instalación automática en esta versión."
 }
 elseif($a.installMode -eq "office365"){
   $ok+="Instalación mediante Office Deployment Tool oficial de Microsoft"
   if(!(Is-Admin)){$warn+="Microsoft 365 necesitará ejecutar SimpleByte Setup como administrador."}
 }
 elseif(!(Has-Winget)){$hard+="WinGet no está disponible."}
 elseif($CheckPackage){
   $p=PackageAvailable $a.id
   if(!$p.Ok){$hard+="El paquete '$($a.id)' no se encontró actualmente en las fuentes WinGet configuradas."}
   else{$ok+="Paquete WinGet disponible"}
 }
 if(IsInstalled $a.id){$warn+="La aplicación ya parece estar instalada."}
 if(!(Is-Admin)){$warn+="La sesión no está elevada. El instalador puede solicitar UAC."}
 if($hard.Count){$state="NO COMPATIBLE"}
 elseif($warn.Count){$state="COMPATIBLE CON ADVERTENCIAS"}
 else{$state="COMPATIBLE"}
 return [pscustomobject]@{State=$state;Hard=$hard;Warn=$warn;Ok=$ok}
}
function Format-Compatibility($r){
 $s="RESULTADO: $($r.State)`r`n`r`n"
 foreach($x in $r.Ok){$s+="[OK] $x`r`n"}
 foreach($x in $r.Warn){$s+="[!] $x`r`n"}
 foreach($x in $r.Hard){$s+="[X] $x`r`n"}
 return $s
}
function Verify-App($a){switch($a.postInstall){"java"{return(& java -version 2>&1|Out-String)}"python"{return(& python --version 2>&1|Out-String)}"node"{return((& node --version 2>&1|Out-String)+(& npm --version 2>&1|Out-String))}"dotnet"{return(& dotnet --info 2>&1|Out-String)}default{return""}}}
function ConfigureJava($a){$major=([regex]::Match($a.name,"\d+")).Value;$pats=@("C:\Program Files\Eclipse Adoptium\jdk-$major*","C:\Program Files\Microsoft\jdk-$major*","C:\Program Files\Java\jdk-$major*");$d=$null;foreach($p in $pats){$d=Get-ChildItem $p -Directory -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1;if($d){break}};if($d){[Environment]::SetEnvironmentVariable("JAVA_HOME",$d.FullName,"User");$up=[Environment]::GetEnvironmentVariable("Path","User");if(!$up){$up=""};$parts=@($up.Split(";")|?{$_});if($parts-notcontains"%JAVA_HOME%\bin"){[Environment]::SetEnvironmentVariable("Path",(($parts+"%JAVA_HOME%\bin")-join";"),"User")};Log "JAVA_HOME=$($d.FullName)"}}


function Install-Microsoft365 {
  if(!(Is-Admin)){
    [Windows.Forms.MessageBox]::Show("Microsoft 365 requiere ejecutar SimpleByte Setup como administrador.","Microsoft 365")|Out-Null
    return 740
  }
  $odtDir=Join-Path $Root "office365"
  if(!(Test-Path $odtDir)){New-Item $odtDir -ItemType Directory|Out-Null}
  $cfg=Join-Path $odtDir "configuration.xml"
  @"
<Configuration>
  <Add OfficeClientEdition="64" Channel="Current">
    <Product ID="O365ProPlusRetail">
      <Language ID="es-es" />
    </Product>
  </Add>
  <Updates Enabled="TRUE" />
  <Display Level="None" AcceptEULA="TRUE" />
</Configuration>
"@ | Set-Content $cfg -Encoding UTF8

  # Official Microsoft Download Center confirmation endpoint for ODT.
  # We deliberately download the current ODT each time instead of bundling an old copy.
  $page="https://www.microsoft.com/en-us/download/details.aspx?id=49117"
  $status.Text="Microsoft 365: obteniendo Office Deployment Tool oficial..."
  $form.Refresh()
  try {
    $html=(Invoke-WebRequest -Uri $page -UseBasicParsing -ErrorAction Stop).Content
    $m=[regex]::Match($html,'https://download\.microsoft\.com/download/[^"''<> ]+/officedeploymenttool_[^"''<> ]+\.exe',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if(!$m.Success){throw "No se pudo localizar el enlace actual de ODT en Microsoft Download Center."}
    $odtBootstrap=Join-Path $odtDir "officedeploymenttool.exe"
    Invoke-WebRequest -Uri $m.Value -OutFile $odtBootstrap -UseBasicParsing -ErrorAction Stop
    $extract=Join-Path $odtDir "ODT"
    if(!(Test-Path $extract)){New-Item $extract -ItemType Directory|Out-Null}
    $p=Start-Process $odtBootstrap -ArgumentList "/quiet /extract:`"$extract`"" -Wait -PassThru
    $setup=Join-Path $extract "setup.exe"
    if(!(Test-Path $setup)){throw "ODT se descargó, pero setup.exe no fue extraído."}
    Log "ODT oficial descargado. Iniciando Microsoft 365 Apps."
    $status.Text="Microsoft 365: descargando e instalando desde Microsoft..."
    $form.Refresh()
    $p=Start-Process $setup -ArgumentList "/configure `"$cfg`"" -Wait -PassThru
    return $p.ExitCode
  } catch {
    Log ("Error Microsoft 365: "+$_.Exception.Message)
    [Windows.Forms.MessageBox]::Show($_.Exception.Message,"Microsoft 365")|Out-Null
    return 1
  }
}

$form=New-Object Windows.Forms.Form;$form.Text="SimpleByte Setup v2.1.2";$form.Size="1200,790";$form.MinimumSize="1000,700";$form.StartPosition="CenterScreen";$form.Font=New-Object Drawing.Font("Segoe UI",9)
$title=New-Object Windows.Forms.Label;$title.Text="SimpleByte Setup";$title.Font=New-Object Drawing.Font("Segoe UI Semibold",21);$title.AutoSize=$true;$title.Location="20,14";$form.Controls.Add($title)
$sub=New-Object Windows.Forms.Label;$sub.Text="Catálogo · licencias · prevalidación de compatibilidad · instalación";$sub.AutoSize=$true;$sub.Location="23,55";$form.Controls.Add($sub)
$sys=New-Object Windows.Forms.Label;$sys.AutoSize=$true;$sys.Location="800,28";$sys.Text="Sistema: $(Get-Arch) · RAM $(Get-RamGB) GB · Libre $(Get-FreeGB) GB · WinGet: $(if(Has-Winget){'OK'}else{'NO'})";$form.Controls.Add($sys)
$cat=New-Object Windows.Forms.ComboBox;$cat.DropDownStyle="DropDownList";$cat.Location="22,84";$cat.Width=205;[void]$cat.Items.Add("Todas");$Catalog.apps.category|Sort-Object -Unique|%{[void]$cat.Items.Add($_)};$cat.SelectedIndex=0;$form.Controls.Add($cat)
$lic=New-Object Windows.Forms.ComboBox;$lic.DropDownStyle="DropDownList";$lic.Location="235,84";$lic.Width=195;[void]$lic.Items.Add("Todas las licencias");$Catalog.apps.licenseType|Sort-Object -Unique|%{[void]$lic.Items.Add($_)};$lic.SelectedIndex=0;$form.Controls.Add($lic)
$search=New-Object Windows.Forms.TextBox;$search.Location="438,84";$search.Width=240;$form.Controls.Add($search)
$profile=New-Object Windows.Forms.ComboBox;$profile.DropDownStyle="DropDownList";$profile.Location="686,84";$profile.Width=205;[void]$profile.Items.Add("Perfil: ninguno");$Catalog.profiles.PSObject.Properties.Name|%{[void]$profile.Items.Add("Perfil: $_")};$profile.SelectedIndex=0;$form.Controls.Add($profile)
$detect=New-Object Windows.Forms.Button;$detect.Text="Detectar instalados";$detect.Location="900,81";$detect.Size="125,30";$form.Controls.Add($detect)
$pre=New-Object Windows.Forms.Button;$pre.Text="Prevalidar";$pre.Location="1033,81";$pre.Size="125,30";$form.Controls.Add($pre)

$grid=New-Object Windows.Forms.DataGridView;$grid.Location="22,125";$grid.Size="1135,300";$grid.AllowUserToAddRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode="Fill";$grid.SelectionMode="FullRowSelect";$grid.MultiSelect=$false
$c=New-Object Windows.Forms.DataGridViewCheckBoxColumn;$c.Name="Sel";$c.HeaderText="✓";$c.FillWeight=15;[void]$grid.Columns.Add($c)
foreach($x in @(@("Nombre","Aplicación",100),@("Categoria","Categoría",65),@("Licencia","Licencia",80),@("Estado","Instalación",45),@("Compat","Compatibilidad",65))){$c=New-Object Windows.Forms.DataGridViewTextBoxColumn;$c.Name=$x[0];$c.HeaderText=$x[1];$c.FillWeight=$x[2];$c.ReadOnly=$true;[void]$grid.Columns.Add($c)}
$form.Controls.Add($grid)

$info=New-Object Windows.Forms.GroupBox;$info.Text="Información del programa";$info.Location="22,435";$info.Size="1135,115";$form.Controls.Add($info)
$desc=New-Object Windows.Forms.Label;$desc.Location="12,22";$desc.Size="1105,38";$info.Controls.Add($desc)
$meta=New-Object Windows.Forms.Label;$meta.Location="12,62";$meta.Size="1105,44";$info.Controls.Add($meta)
function Fill{$sel=@();foreach($r in $grid.Rows){if($r.Cells["Sel"].Value){$sel+=[string]$r.Tag.id}};$grid.Rows.Clear();$q=$search.Text.Trim().ToLower();$cc=[string]$cat.SelectedItem;$ll=[string]$lic.SelectedItem;foreach($a in $Catalog.apps){if($cc-ne"Todas"-and$a.category-ne$cc){continue};if($ll-ne"Todas las licencias"-and$a.licenseType-ne$ll){continue};$hay=($a.name+" "+$a.description+" "+$a.alternativeTo+" "+$a.id).ToLower();if($q-and$hay-notlike"*$q*"){continue};$i=$grid.Rows.Add();$r=$grid.Rows[$i];$r.Tag=$a;$r.Cells["Sel"].Value=$sel-contains$a.id;$r.Cells["Nombre"].Value=$a.name;$r.Cells["Categoria"].Value=$a.category;$r.Cells["Licencia"].Value=$a.licenseType;$r.Cells["Estado"].Value="Sin comprobar";$r.Cells["Compat"].Value="Sin validar"}}
Fill
$cat.Add_SelectedIndexChanged({Fill});$lic.Add_SelectedIndexChanged({Fill});$search.Add_TextChanged({Fill})
$grid.Add_SelectionChanged({if($grid.SelectedRows.Count){$a=$grid.SelectedRows[0].Tag;if($a){$desc.Text=$a.description;$alt=if($a.alternativeTo){" | Alternativa a: "+$a.alternativeTo}else{""};$meta.Text="Licencia: $($a.licenseType) ($($a.license)) | Fuente: $($a.source)$alt`r`nID: $($a.id)"}}})
$profile.Add_SelectedIndexChanged({if($profile.SelectedIndex-le 0){return};$n=$profile.SelectedItem.ToString().Replace("Perfil: ","");$ids=@($Catalog.profiles.$n);foreach($r in $grid.Rows){$r.Cells["Sel"].Value=$ids-contains[string]$r.Tag.id}})
$detect.Add_Click({$status.Text="Comprobando instalaciones...";$form.Refresh();foreach($r in $grid.Rows){$r.Cells["Estado"].Value=if(IsInstalled([string]$r.Tag.id)){"Instalado"}else{"Disponible"};[Windows.Forms.Application]::DoEvents()};$status.Text="Comprobación terminada."})
$pre.Add_Click({
 $rows=@($grid.Rows|?{$_.Cells["Sel"].Value});if(!$rows.Count -and $grid.SelectedRows.Count){$rows=@($grid.SelectedRows[0])}
 if(!$rows.Count){[Windows.Forms.MessageBox]::Show("Selecciona una aplicación o marca varias.")|Out-Null;return}
 $out.Clear();$status.Text="Prevalidando $($rows.Count) elemento(s)...";$form.Refresh()
 foreach($r in $rows){$a=$r.Tag;$res=Test-Compatibility $a $true;$r.Cells["Compat"].Value=$res.State;$out.AppendText("=== $($a.name) ===`r`n$(Format-Compatibility $res)`r`n");Log "Compatibilidad $($a.name): $($res.State)";[Windows.Forms.Application]::DoEvents()}
 $status.Text="Prevalidación terminada."
})

$out=New-Object Windows.Forms.TextBox;$out.Location="22,560";$out.Size="865,150";$out.Multiline=$true;$out.ScrollBars="Vertical";$out.ReadOnly=$true;$out.Font=New-Object Drawing.Font("Consolas",8);$form.Controls.Add($out)
$status=New-Object Windows.Forms.Label;$status.Text="Listo.";$status.Location="22,718";$status.AutoSize=$true;$form.Controls.Add($status)
$install=New-Object Windows.Forms.Button;$install.Text="PREVALIDAR E INSTALAR";$install.Location="905,565";$install.Size="252,45";$form.Controls.Add($install)
$verify=New-Object Windows.Forms.Button;$verify.Text="VERIFICAR SELECCIONADO";$verify.Location="905,620";$verify.Size="252,38";$form.Controls.Add($verify)
$compatOne=New-Object Windows.Forms.Button;$compatOne.Text="DETALLE COMPATIBILIDAD";$compatOne.Location="905,667";$compatOne.Size="252,38";$form.Controls.Add($compatOne)
$verify.Add_Click({if($grid.SelectedRows.Count){$a=$grid.SelectedRows[0].Tag;$v=Verify-App $a;if(!$v){$v="Esta aplicación no tiene verificación post-instalación especial configurada."};[Windows.Forms.MessageBox]::Show($v,"Verificación - "+$a.name)|Out-Null}})
$compatOne.Add_Click({if($grid.SelectedRows.Count){$a=$grid.SelectedRows[0].Tag;$r=Test-Compatibility $a $true;[Windows.Forms.MessageBox]::Show((Format-Compatibility $r),"Compatibilidad - "+$a.name)|Out-Null}})
$install.Add_Click({
 $items=@();foreach($r in $grid.Rows){if($r.Cells["Sel"].Value){$items+=@{A=$r.Tag;R=$r}}}
 if(!$items.Count){[Windows.Forms.MessageBox]::Show("Selecciona al menos una aplicación.")|Out-Null;return}
 $good=@();$warn=@();$bad=@();$out.Clear();$status.Text="Prevalidando antes de instalar...";$form.Refresh()
 foreach($it in $items){$res=Test-Compatibility $it.A $true;$it.R.Cells["Compat"].Value=$res.State;if($res.State-eq"NO COMPATIBLE"){$bad+=$it}elseif($res.State-eq"COMPATIBLE CON ADVERTENCIAS"){$warn+=$it;$good+=$it}else{$good+=$it};$out.AppendText("=== $($it.A.name) ===`r`n$(Format-Compatibility $res)`r`n");[Windows.Forms.Application]::DoEvents()}
 $msg="Prevalidación:`n`nCompatibles para continuar: $($good.Count)`nCon advertencias: $($warn.Count)`nBloqueados: $($bad.Count)`n`nLos bloqueados NO se instalarán."
 if(!$good.Count){[Windows.Forms.MessageBox]::Show($msg,"SimpleByte Setup")|Out-Null;$status.Text="No hay elementos aptos para instalar.";return}
 if([Windows.Forms.MessageBox]::Show($msg+"`n`n¿Instalar los compatibles?","SimpleByte Setup","YesNo","Question")-ne"Yes"){return}
 $install.Enabled=$false
 foreach($it in $good){$a=$it.A;$status.Text="Instalando: $($a.name)";$form.Refresh();
  if($a.installMode -eq "office365"){
    $out.AppendText("Microsoft 365: usando Office Deployment Tool oficial...`r`n")
    $code=Install-Microsoft365
    $it.R.Cells["Estado"].Value=if($code-eq 0){"Instalado"}else{"Error $code"}
    $out.AppendText("Microsoft 365 finalizado (código $code).`r`n")
    continue
  }
  if($a.installMode -eq "external" -or $a.installMode -eq "reference"){
    $out.AppendText("$($a.name): fuente externa/referencia. Abriendo página oficial...`r`n")
    if($a.installUrl){Start-Process $a.installUrl}
    $it.R.Cells["Estado"].Value="Fuente externa"
    continue
  }
  if(!(Has-Winget)){$out.AppendText("$($a.name): WinGet no disponible.`r`n");$it.R.Cells["Estado"].Value="Sin WinGet";continue}
  if(IsInstalled $a.id){$out.AppendText("$($a.name): ya instalado.`r`n");$it.R.Cells["Estado"].Value="Instalado";continue};Log "Instalando $($a.name) [$($a.id)]";& winget install --id $a.id -e --accept-source-agreements --accept-package-agreements --silent --disable-interactivity 2>&1|%{$out.AppendText($_.ToString()+"`r`n");Log $_;[Windows.Forms.Application]::DoEvents()};$code=$LASTEXITCODE;if($code-eq 0-and$a.postInstall-eq"java"){ConfigureJava $a};$it.R.Cells["Estado"].Value=if($code-eq 0){"Instalado"}else{"Error $code"};$out.AppendText("Finalizado: $($a.name) (código $code)`r`n")}
 $install.Enabled=$true;$status.Text="Proceso terminado. Revisa resultados y log."
})
Log "SimpleByte Setup v2.1.2 iniciado"
[void]$form.ShowDialog()
