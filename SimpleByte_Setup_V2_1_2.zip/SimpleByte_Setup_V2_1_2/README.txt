SIMPLEBYTE SETUP V2.1
======================

Catálogo: 147 aplicaciones/componentes.

NOVEDAD PRINCIPAL: PREVALIDACIÓN DE COMPATIBILIDAD
- Detecta arquitectura del equipo.
- Lee RAM instalada.
- Comprueba espacio libre en la unidad del sistema.
- Lee build de Windows.
- Comprueba disponibilidad de WinGet.
- Consulta si el ID del paquete existe en las fuentes WinGet configuradas.
- Detecta si la aplicación ya está instalada.
- Advierte si la sesión no está elevada.
- Para software documentado en el catálogo, valida RAM/espacio/arquitectura.
- Para VirtualBox, VMware y Docker comprueba virtualización de hardware cuando Windows expone el dato.
- Bloquea la instalación automática si encuentra un requisito duro incumplido.
- Permite continuar con elementos compatibles aunque otros queden bloqueados.
- Muestra Compatible / Compatible con advertencias / No compatible.

IMPORTANTE
La prevalidación reduce fallos previsibles, pero no garantiza compatibilidad absoluta.
Drivers, GPU, políticas corporativas, requisitos del fabricante y dependencias externas pueden
afectar una instalación. Los requisitos específicos se guardan en catalog.json y pueden ampliarse.

La clasificación de licencias es informativa; prevalecen siempre los términos vigentes del proveedor.


ACTUALIZACIÓN 2.1.1
- Catálogo ampliado a 151 entradas.
- Nueva categoría: Etiquetado e impresión.
- ANLAbel (GPL-3.0): Excel/CSV -> etiquetas industriales.
- ZPLab (MIT): diseñador ZPL con Excel/CSV/base de datos.
- LabelForge (MIT): diseñador/impresión ZPL y lotes CSV.
- BarTender incluido como referencia comercial para comparación.
- Los proyectos GitHub se marcan como fuente externa y NO se intentan instalar con un ID WinGet inventado.
  Al seleccionarlos para instalación se abre su página oficial.


ACTUALIZACIÓN 2.1.2
- 152 entradas.
- Se mantienen ANLAbel, ZPLab y LabelForge como alternativas libres de etiquetado.
- Se agrega Microsoft 365 Apps (Office).
- Microsoft 365 se instala con la Office Deployment Tool oficial de Microsoft.
- Configuración predeterminada: 64 bits, español (es-es), Current Channel, Microsoft 365 Apps for enterprise.
- SimpleByte descarga la ODT actual desde Microsoft en el momento de instalar; no incluye cracks, activadores ni licencias.
- Microsoft 365 requiere licencia/suscripción válida y permisos de administrador local.
